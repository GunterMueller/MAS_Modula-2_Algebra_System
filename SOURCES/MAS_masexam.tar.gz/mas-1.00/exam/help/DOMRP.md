(* ----------------------------------------------------------------------------
 * $Id: DOMRP.md,v 1.1 1992/06/12 13:48:04 kredel Exp $
 * ----------------------------------------------------------------------------
 * This file is part of MAS.
 * ----------------------------------------------------------------------------
 * Copyright (c) 1989 - 1992 Universitaet Passau
 * ----------------------------------------------------------------------------
 * $Log: DOMRP.md,v $
 * Revision 1.1  1992/06/12  13:48:04  kredel
 * Initial revision
 *
 * ----------------------------------------------------------------------------
 *)

DEFINITION MODULE DOMRP;

(* MAS Domain Rational Polynomial Definition Module. *)


FROM MASADOM IMPORT Domain;

CONST rcsid = "$Id: DOMRP.md,v 1.1 1992/06/12 13:48:04 kredel Exp $";
CONST copyright = "Copyright (c) 1989 - 1992 Universitaet Passau";


VAR DOMRPD: Domain;


PROCEDURE DomLoadRP();
(*Domain load rational polynomials . *)


END DOMRP.


(* -EOF- *)
