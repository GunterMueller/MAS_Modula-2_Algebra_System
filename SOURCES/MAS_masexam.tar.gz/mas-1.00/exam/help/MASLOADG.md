(* ----------------------------------------------------------------------------
 * $Id: MASLOADG.md,v 1.1 1995/11/05 15:29:37 pesch Exp $
 * ----------------------------------------------------------------------------
 * This file is part of MAS.
 * ----------------------------------------------------------------------------
 * Copyright (c) 1995 Universitaet Passau
 * ----------------------------------------------------------------------------
 * $Log: MASLOADG.md,v $
 * Revision 1.1  1995/11/05  15:29:37  pesch
 * *** empty log message ***
 *
 * ----------------------------------------------------------------------------
 *)

DEFINITION MODULE MASLOADG;

(* MAS Load Symmetric Functions Definition Module. *)


CONST rcsid = "$Id: MASLOADG.md,v 1.1 1995/11/05 15:29:37 pesch Exp $";
CONST copyright = "Copyright (c) 1995 Universitaet Passau";

PROCEDURE InitExternalsG;
(*Tell Modula and LISP about external compiled procedures. *)

END MASLOADG.
(* -EOF- *)




