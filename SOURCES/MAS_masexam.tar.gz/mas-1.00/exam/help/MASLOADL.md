(* ----------------------------------------------------------------------------
 * $Id: MASLOADL.md,v 1.1 1992/01/22 15:11:54 kredel Exp $
 * ----------------------------------------------------------------------------
 * This file is part of MAS.
 * ----------------------------------------------------------------------------
 * Copyright (c) 1989 - 1992 Universitaet Passau
 * ----------------------------------------------------------------------------
 * $Log: MASLOADL.md,v $
 * Revision 1.1  1992/01/22  15:11:54  kredel
 * Initial revision
 *
 * ----------------------------------------------------------------------------
 *)

DEFINITION MODULE MASLOADL;

(* MAS Load Definition Module L. *)

CONST rcsid = "$Id: MASLOADL.md,v 1.1 1992/01/22 15:11:54 kredel Exp $";
CONST copyright = "Copyright (c) 1989 - 1992 Universitaet Passau";



PROCEDURE InitExternalsL();
(*Initialize external compiled linear algebra procedures. *)

END MASLOADL.

(* -EOF- *)
