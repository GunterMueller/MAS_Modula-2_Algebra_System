(* ----------------------------------------------------------------------------
 * $Id: MASLOADM.md,v 1.2 1995/12/16 14:57:49 kredel Exp $
 * ----------------------------------------------------------------------------
 * This file is part of MAS.
 * ----------------------------------------------------------------------------
 * Copyright (c) 1993 Universitaet Passau
 * ----------------------------------------------------------------------------
 * $Log: MASLOADM.md,v $
 * Revision 1.2  1995/12/16  14:57:49  kredel
 * Provided module comment.
 *
 * Revision 1.1  1994/03/11  15:37:30  pesch
 * Diplomarbeit F. Lippold
 *
 * ----------------------------------------------------------------------------
 *)

DEFINITION MODULE MASLOADM;

(* MAS Load Definition Module M. *)


CONST rcsid = "$Id: MASLOADM.md,v 1.2 1995/12/16 14:57:49 kredel Exp $";
CONST copyright = "Copyright (c) 1993 Universitaet Passau";
	
PROCEDURE InitExternalsM;
(*Initialize external compiled real root procedures. *)

END MASLOADM.

(* -EOF- *)
