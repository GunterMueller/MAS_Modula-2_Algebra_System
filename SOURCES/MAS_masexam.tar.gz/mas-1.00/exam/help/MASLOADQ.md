(* ----------------------------------------------------------------------------
 * $Id: MASLOADQ.md,v 1.1 1992/09/28 17:56:18 kredel Exp $
 * ----------------------------------------------------------------------------
 * This file is part of MAS.
 * ----------------------------------------------------------------------------
 * Copyright (c) 1989 - 1992 Universitaet Passau
 * ----------------------------------------------------------------------------
 * $Log: MASLOADQ.md,v $
 * Revision 1.1  1992/09/28  17:56:18  kredel
 * Initial revision
 *
 * ----------------------------------------------------------------------------
 *)

DEFINITION MODULE MASLOADQ;

(* MAS Load Definition Module Q. *)

CONST rcsid = "$Id: MASLOADQ.md,v 1.1 1992/09/28 17:56:18 kredel Exp $";
CONST copyright = "Copyright (c) 1989 - 1992 Universitaet Passau";


PROCEDURE InitExternalsQ;
(*Initialize external compiled arithmetic Q procedures. *)

END MASLOADQ.



(* -EOF- *)
