(* ----------------------------------------------------------------------------
 * $Id: MASLOADB.md,v 1.1 1992/01/22 15:11:47 kredel Exp $
 * ----------------------------------------------------------------------------
 * This file is part of MAS.
 * ----------------------------------------------------------------------------
 * Copyright (c) 1989 - 1992 Universitaet Passau
 * ----------------------------------------------------------------------------
 * $Log: MASLOADB.md,v $
 * Revision 1.1  1992/01/22  15:11:47  kredel
 * Initial revision
 *
 * ----------------------------------------------------------------------------
 *)

DEFINITION MODULE MASLOADB;

(* MAS Load Definition Module B. *)

CONST rcsid = "$Id: MASLOADB.md,v 1.1 1992/01/22 15:11:47 kredel Exp $";
CONST copyright = "Copyright (c) 1989 - 1992 Universitaet Passau";



PROCEDURE InitExternalsB;
(*Initialize external compiled polynomial procedures. *)

END MASLOADB.



(* -EOF- *)
