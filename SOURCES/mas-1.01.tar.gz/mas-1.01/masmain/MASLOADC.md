(* ----------------------------------------------------------------------------
 * $Id: MASLOADC.md,v 1.1 1992/01/22 15:11:49 kredel Exp $
 * ----------------------------------------------------------------------------
 * This file is part of MAS.
 * ----------------------------------------------------------------------------
 * Copyright (c) 1989 - 1992 Universitaet Passau
 * ----------------------------------------------------------------------------
 * $Log: MASLOADC.md,v $
 * Revision 1.1  1992/01/22  15:11:49  kredel
 * Initial revision
 *
 * ----------------------------------------------------------------------------
 *)

DEFINITION MODULE MASLOADC;

(* MAS Load Definition Module C. *)

CONST rcsid = "$Id: MASLOADC.md,v 1.1 1992/01/22 15:11:49 kredel Exp $";
CONST copyright = "Copyright (c) 1989 - 1992 Universitaet Passau";



PROCEDURE InitExternalsC;
(*Initialize external compiled non-commutative polynomial procedures. *)

END MASLOADC.



(* -EOF- *)
