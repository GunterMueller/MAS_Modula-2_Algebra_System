(* ----------------------------------------------------------------------------
 * $Id: MASLOADD.md,v 1.1 1992/01/22 15:11:51 kredel Exp $
 * ----------------------------------------------------------------------------
 * This file is part of MAS.
 * ----------------------------------------------------------------------------
 * Copyright (c) 1989 - 1992 Universitaet Passau
 * ----------------------------------------------------------------------------
 * $Log: MASLOADD.md,v $
 * Revision 1.1  1992/01/22  15:11:51  kredel
 * Initial revision
 *
 * ----------------------------------------------------------------------------
 *)

DEFINITION MODULE MASLOADD;

(* MAS Load Definition Module D. *)

CONST rcsid = "$Id: MASLOADD.md,v 1.1 1992/01/22 15:11:51 kredel Exp $";
CONST copyright = "Copyright (c) 1989 - 1992 Universitaet Passau";



PROCEDURE InitExternalsD;
(*Initialize external compiled ideal decomposition and root procedures. *)

END MASLOADD.




(* -EOF- *)
