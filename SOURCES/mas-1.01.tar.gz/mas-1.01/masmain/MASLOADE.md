(* ----------------------------------------------------------------------------
 * $Id: MASLOADE.md,v 1.1 1992/01/22 15:11:52 kredel Exp $
 * ----------------------------------------------------------------------------
 * This file is part of MAS.
 * ----------------------------------------------------------------------------
 * Copyright (c) 1989 - 1992 Universitaet Passau
 * ----------------------------------------------------------------------------
 * $Log: MASLOADE.md,v $
 * Revision 1.1  1992/01/22  15:11:52  kredel
 * Initial revision
 *
 * ----------------------------------------------------------------------------
 *)

DEFINITION MODULE MASLOADE;

(* MAS Load Definition Module E. *)

CONST rcsid = "$Id: MASLOADE.md,v 1.1 1992/01/22 15:11:52 kredel Exp $";
CONST copyright = "Copyright (c) 1989 - 1992 Universitaet Passau";



PROCEDURE InitExternalsE;
(*Initialize external compiled arbitrary domain procedures. *)

END MASLOADE.



(* -EOF- *)
