(* ----------------------------------------------------------------------------
 * $Id: MASLOADJ.md,v 1.1 1995/10/12 14:43:41 pesch Exp $
 * ----------------------------------------------------------------------------
 * This file is part of MAS.
 * ----------------------------------------------------------------------------
 * Copyright (c) 1995 Universitaet Passau
 * ----------------------------------------------------------------------------
 * $Log: MASLOADJ.md,v $
 * Revision 1.1  1995/10/12 14:43:41  pesch
 * Diplomarbeit Rainer Grosse-Gehling.
 * Involutive Bases.
 * Slightly edited.
 *
 * ----------------------------------------------------------------------------
 *)

DEFINITION MODULE MASLOADJ;

(* MAS Load Definition Module J. *)


CONST rcsid = "$Id: MASLOADJ.md,v 1.1 1995/10/12 14:43:41 pesch Exp $";
CONST copyright = "Copyright (c) 1995 Universitaet Passau";



PROCEDURE InitExternalsJ;
(*Initialize external compiled arithmetic procedures. *)

END MASLOADJ.       
